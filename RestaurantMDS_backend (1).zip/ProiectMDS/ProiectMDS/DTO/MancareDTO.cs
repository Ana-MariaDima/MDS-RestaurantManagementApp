﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectMDS.ProiectMDS.DTO
{
    public class MancareDTO
    {
        public string Nume { get; set; }
        public int Cantitate { get; set; }
    }
}
