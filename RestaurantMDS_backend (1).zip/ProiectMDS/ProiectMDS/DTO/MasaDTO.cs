﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectMDS.ProiectMDS.DTO
{
    public class MasaDTO
    {
        public int NrLocuri { get; set; }
        public string Locatie { get; set; }

    }
}
