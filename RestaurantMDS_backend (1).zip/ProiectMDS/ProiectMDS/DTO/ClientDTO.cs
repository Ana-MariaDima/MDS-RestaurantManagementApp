﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectMDS.ProiectMDS.DTO
{
    public class ClientDTO
    {
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public string NrTelefon { get; set; }
    }
}
