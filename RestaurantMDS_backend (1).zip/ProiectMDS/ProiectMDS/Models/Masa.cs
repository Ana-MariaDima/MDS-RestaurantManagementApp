﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProiectMDS.ProiectMDS.Models
{
    public class Masa
    {
        public int Id { get; set; }

        public int NrLocuri { get; set; }
        public string Locatie { get; set; }
    }
}
