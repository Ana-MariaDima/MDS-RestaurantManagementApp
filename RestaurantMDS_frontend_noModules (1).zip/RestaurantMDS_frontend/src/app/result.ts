export class Result {
}
